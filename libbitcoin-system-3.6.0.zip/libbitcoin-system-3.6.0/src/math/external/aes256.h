/**
 *   Byte-oriented AES-256 implementation.
 *   All lookup tables replaced with 'on the fly' calculations. 
 *
 *   Copyright (c) 2007-2009 Ilya O. Levin, http://www.literatecode.com
 *   Other contributors: Hal Finney
 *
 *   Permission to use, copy, modify, and distribute this software for any
 *   purpose with or without fee is hereby granted, provided that the above
 *   copyright notice and this permission notice appear in all copies.
 *
 *   THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 *   WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 *   MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 *   ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 *   WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 *   ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 *   OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */
#ifndef LIBBITCOIN_AES256_H
#define LIBBITCOIN_AES256_H

#include <stdint.h>
#include <stdlib.h>

#define AES256_KEY_LENGTH 32U
#define AES256_BLOCK_LENGTH 16U

#ifdef __cplusplus
extern "C" { 
#endif

typedef struct
{
    uint8_t key[AES256_KEY_LENGTH];
    uint8_t enckey[AES256_KEY_LENGTH];
    uint8_t deckey[AES256_KEY_LENGTH];
} aes256_context; 

void aes256_init(aes256_context* context, 
    const uint8_t key[AES256_KEY_LENGTH]);

void aes256_done(aes256_context* context);

void aes256_encrypt_ecb(aes256_context* context,
    uint8_t plain_text[AES256_BLOCK_LENGTH]);

void aes256_decrypt_ecb(aes256_context* context,
    uint8_t cypher_text[AES256_BLOCK_LENGTH]);

#ifdef __cplusplus
}
#endif

#endif
